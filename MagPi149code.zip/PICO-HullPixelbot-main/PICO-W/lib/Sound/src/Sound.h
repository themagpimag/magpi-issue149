

void setupSound();
void playTone(int frequency, unsigned long duration);

