void setupServer();

void updateServer();
