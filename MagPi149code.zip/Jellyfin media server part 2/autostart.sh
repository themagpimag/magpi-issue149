#!/bin/bash
(
sleep 10
echo -e "connect XX:XX:XX:XX:XX:XX\nexit" | bluetoothctl
sleep 10
) &

